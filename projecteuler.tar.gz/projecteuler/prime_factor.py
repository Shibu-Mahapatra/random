#
# Solution to Project Euler problem 3
#
import primefac
n = int(input("enter number: "))
factors = set(primefac.primefac(n))
print max(factors)
