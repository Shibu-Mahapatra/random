#
# Solution to Project Euler problem 2
#


def compute():
    n1 = int(input("enter starting value: "))  # 1
    n2 = int(input("enter next value: "))  # 2
    total = 0
    while n1 <= 4000000:
        if n1 % 2 == 0:
            total += n1
        n1, n2 = n2, n1+n2
    return str(total)

if __name__ == "__main__":
    print (compute())




