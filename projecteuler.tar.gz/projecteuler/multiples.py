#
# Solution to Project Euler problem 1
#


n1 = int(input("enter first number: "))
n2 = int(input("enter second number: "))
n3 = int(input("enter range: "))


def sum_of_multiples(a, b, limit):
    new_lst = []
    for i in range(limit):
        if i % a == 0 or i % b == 0:
            new_lst.append(i)
    return str(sum(new_lst))

val = sum_of_multiples(n1, n2, n3)
print ("sum of first "+str(n3)+" multiples of "+str(n1) + " or " + str(n2) + ":is "+str(val))

